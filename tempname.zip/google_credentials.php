<?php

$api_key = "AIzaSyCa1HmrFKoq8gQJ5Vb77-ul56KzqgMPn9M";
$service_url = 'https://kgsearch.googleapis.com/v1/entities:search';

?>
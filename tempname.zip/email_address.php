<?php 

$mypersonalemail = 'ferlat.simon@gmail.com';

?>
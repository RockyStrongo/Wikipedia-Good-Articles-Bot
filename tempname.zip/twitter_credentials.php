<?php  
$consumerKey = '8hvgaDYQ3XnLPqbM1BYLQCCyW';
$consumerSecret = 'xBoA3qnvnCSq4E93fvjsBakv0TRbEbjCvINW5BFlQ4Cr8fnorg';
$accessToken = '1189821940384587776-JGltYitf6uKe0QNJ4J2sqGqF7WtHzt';
$accessTokenSecret = '0z4bcFiGiJhASZw6T6A35knml4GrunjxUq3IMHcW23Gy7';
?>